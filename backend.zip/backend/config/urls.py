from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/", include("apps.accounts.urls")),
    path("api/", include("apps.core.urls")),
    path("api/exportar/", include("apps.exports.urls")),
    path("api/estadisticas/", include("apps.stats.urls")),
]
